﻿using Srez.Database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Srez.Pages
{
    /// <summary>
    /// Логика взаимодействия для AuthPage.xaml
    /// </summary>
    public partial class AuthPage : Page
    {
        public AuthPage()
        {
            InitializeComponent();

        }

        private void EnterButton_Click(object sender, RoutedEventArgs e)
        {
            string Password = PasswordBox.Text;
            string Login = LoginBox.Text;

            if ((BD.entities.UserObj.FirstOrDefault(c => c.UserLogin == Login && c.UserPassword == Password) != null))
            {
                UserObj user = BD.entities.UserObj.FirstOrDefault(C => C.UserPassword == Password && C.UserLogin == Login);
                NavigationService.Navigate(new OrderPage());
            }
            else
            {
                MessageBox.Show("Ошибка авторизации");
            }
        }
    }
}
