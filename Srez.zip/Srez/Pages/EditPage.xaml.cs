﻿using Srez.Database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Srez.Pages
{
    /// <summary>
    /// Логика взаимодействия для EditPage.xaml
    /// </summary>
    public partial class EditPage : Page
    {
        Order _order;
        bool isEditing = true;
        public EditPage()
        {
            InitializeComponent();
            _order = new Order();
            isEditing = false;
        }
        public EditPage(Order order)
        {
            InitializeComponent();
            _order = order;

        }
        

        private void EditSave_Click(object sender, RoutedEventArgs e)
        {
            if (!isEditing)
            {
                try
                {
                    BD.entities.Order.Add(_order);
                    BD.entities.SaveChanges();
                    MessageBox.Show("Объект успешно добавлен", "Сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
                    NavigationService.Navigate(new OrderPage());
                }
                catch
                {
                    MessageBox.Show("Невозможно добавить объект!", "Сообщение", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                try
                {
                    BD.entities.SaveChanges();
                    MessageBox.Show("Объект успешно изменён", "Сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
                    NavigationService.Navigate(new OrderPage());
                }
                catch
                {
                    MessageBox.Show("Невозможно изменить объект!", "Сообщение", MessageBoxButton.OK, MessageBoxImage.Error);
                }

            }
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            this.DataContext = _order;
        }
    }
}
